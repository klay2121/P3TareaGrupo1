/**
 * 
 */
/**
 * 
 */
module SopaDeLetras {
	requires java.desktop;
}